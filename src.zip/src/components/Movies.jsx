import React, { useState } from 'react';

const Movies = (data) => {
    const [ movie, setMovie ] = useState(data.movie);
    const [ rating, setRating ] = useState(data.movie.rating);
   
    console.log(movie)
   
    const average = (array) => {
        const sum = array.reduce((a, b) => a + b, 0);
        let avg = (sum / array.length) || 0;
        return avg.toFixed(2)
    }
    
    const vote = (value) => {
        setRating([...rating, value])
    }
   
    return (
       <div>
         
            <div className="movie-rating">
                <h2>{movie.name}</h2>
                <img src={movie.img} alt={movie.name} />
                <div className="movie-rating-avg">
                    {average(rating)}
                </div>
                
             
                <div>
                    <button onClick={() => vote(1)}>
                        1
                    </button>
                    <button onClick={() => vote(2)}>
                        2
                    </button>
                    <button onClick={() => vote(3)}>
                        3
                    </button>
                    <button onClick={() => vote(4)}>
                        4
                    </button>
                    <button onClick={() => vote(5)}>
                        5
                    </button>
                </div>
                
          
                <div className='commentSection'>
                    <label for="comment" > comment </label>
                    <textarea id="subject" name="subject" placeholder="Share something about movie" style={{height: "50px", margin: "10px"}}></textarea>
                </div>
            </div>
       </div>
   );
};
 
export default Movies;

