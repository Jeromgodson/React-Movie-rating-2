import React from 'react';
import Movies from '../components/Movies';

const MovieList = ({movieList}) => {
    return (
        <div>
            {movieList.map(movie => {
                return (
                    <Movies key={movie.id} movie={movie} />
                )
            })}
        </div>
    );
 };
  
 export default MovieList;
