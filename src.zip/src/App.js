import React, { useState } from 'react';

import data from "./assets/data/data.json";

import './assets/css/App.css';

import MovieList from "./components/MovieList";



function App() {
  
  const [ movieList, setMovieList ] = useState(data);
   

    return (
      <div className="App">
        <header className='header'>
          <h1> Rate my fvourite movies here</h1>
        </header>
        <MovieList movieList={movieList}/>
      </div>
    );
}

export default App;
